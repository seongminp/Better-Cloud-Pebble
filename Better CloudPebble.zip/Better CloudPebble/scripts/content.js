// contentscript.js

alert("Hello World");